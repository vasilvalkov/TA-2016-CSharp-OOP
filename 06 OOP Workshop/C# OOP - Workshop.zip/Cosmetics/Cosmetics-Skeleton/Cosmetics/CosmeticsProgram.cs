﻿using Cosmetics.Engine;
namespace Cosmetics
{
    public class CosmeticsProgram
    {
        public static void Main()
        {
            CosmeticsEngine.Instance.Start();
        }
    }
}
